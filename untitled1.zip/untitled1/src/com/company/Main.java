package com.company;

public class Main {

    public static void main(String[] args) {
	    System.out.println("intel i-9 işlemci 0.000001 ghz");
    }
}
